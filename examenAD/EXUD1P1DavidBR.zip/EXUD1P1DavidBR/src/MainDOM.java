public class MainDOM {
    public static void main(String[] args) {
        String ruta = "test/AlojamientosHotel.xml";

    }
}
