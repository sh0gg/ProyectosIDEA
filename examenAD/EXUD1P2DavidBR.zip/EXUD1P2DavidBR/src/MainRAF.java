import static logica.GestorFotografos.visualizarRegistros;

public class MainRAF {
    public static void main(String[] args) {
        String rutaDAT = "src/tests/fotografos.dat";
        visualizarRegistros(rutaDAT);
    }
}
