package cocina22;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import org.hibernate.Session;

/**
 *
 * @author usuario
 */
public class CcocinaHB22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //prueba de la conexión
        Session sesion = HibernateUtil1.getSessionFactory().openSession();

        System.out.println("conexión realizada con éxito");
        sesion.close();
//
    }
    
}
